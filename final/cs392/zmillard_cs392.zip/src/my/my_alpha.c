#include "my.h"
void my_alpha(){
	int i;
	for(i = 65; i < 91; i++){
		my_char(i);
	}
}